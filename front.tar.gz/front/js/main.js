//Pausar Vídeo Youtube ao fechar modal
$("#exampleModal").on('hidden.bs.modal', function (e) {
    $("#exampleModal iframe").attr("src", $("#exampleModal iframe").attr("src"));
});


$(function() {

    //GET Ganhadores
    $.ajax({
        dataType: "json",
        url: "js/ganhadores.json",//Trocar para url da api feita no silex
        beforeSend: function(request) {
            request.setRequestHeader("authorization", 'bearer d0763edaa9d9bd2a9516280e9044d885');
        },
    }).done(function(data) {

        $.each(data.premiados, function( index, value ) {
            var $conteudo = $("<div class='col-md-6 item'>\n" +
                "                        <div class='img-wrap calendario'>\n" +
                "                            <span class='calendario-data'>"+value.data+"</span>\n" +
                "                        </div>\n" +
                "                        <div class='ganhadores-info'>\n" +
                "                            <span class='calendario-cidade text-blue'><b>"+value.cidade+"</b></span><br/>\n" +
                "                            <span>Número sorteado: "+value.numeroSorteado+"</span>\n" +
                "                        </div>\n" +
                "                    </div>");

            //var $conteudo2 = "<div class='col-md-6 item'><div class='img-wrap calendario'><span class='calendario-data'>14/09</span></div><div class='ganhadores-info'><span class='calendario-cidade text-blue'><b>São Paulo - SP</b></span><br/><span>Número sorteado: 45646</span></div></div>";
            $( ".ganhadores .itens" ).append( $conteudo);
        });
    });

    //GET Data das Premiações
    $.ajax({
        dataType: "json",
        url: "js/premiacoesData.json",//Trocar para url da api feita no silex
        type: "GET",

    }).done(function(data) {

        $.each(data.datas, function( index, value ) {
            var $conteudo = "<li>\n" +
                "                        <div class=\"img-wrap calendario\">\n" +
                "                            <span class=\"calendario-data\">"+value.rdata+"</span>\n" +
                "                        </div>\n" +
                "                    </li>";
            $( ".data-dos-sorteios ul" ).append( $conteudo);
        });
    });

    /*$.ajax({
        dataType: "json",
        url: "http://silex-api.br/customers",//Trocar para url da api feita no silex
        type: "GET",
        headers: {//Tudo que for passado aqui, deve ser adicionado no headers da api em Access-Control-Allow-Headers
            "Content-Type":"application/json",
            "Authorization":"bearer d0763edaa9d9bd2a9516280e9044d885"

        }

    }).done(function(data) {
        console.log(data);
    });*/

    //EXEMPLO POST - INSERE NOVO CUSTOMER
    $.ajax({
        dataType: "json",
        url: "http://silex-api.br/customer",//Trocar para url da api feita no silex
        type: "POST",
        data: JSON.stringify({ name: "wilson", age : "11",gender:"m",phone:"(22)988515853"}),
        //contentType: 'application/json; charset=utf-8',
        headers: {
            "Content-Type":"application/json",
            "Authorization":"bearer d0763edaa9d9bd2a9516280e9044d885"
        }
    }).done(function(data) {
        console.log(data);
    });

    //EXEMPLO PUT - Atualiza o cliente de ID 51
    /*$.ajax({
        dataType: "json",
        url: "http://silex-api.br/customer/51",//Trocar para url da api feita no silex
        type: "PUT",
        data: JSON.stringify({ name: "wilson", age : "11",gender:"m",phone:"(22)988515853"}),
        //contentType: 'application/json; charset=utf-8',
        headers: {
            "Content-Type":"application/json",
            "Authorization":"bearer d0763edaa9d9bd2a9516280e9044d885"
        }
    }).done(function(data) {
        console.log(data);
    });*/



});